(async () => {
    try {
        var proxyUrl = await PluginDatabase.getCacheKey('proxy_url');
        var tmdb_api_key = await PluginDatabase.getCacheKey('tmdb_api_key');
        var access_token = await PluginDatabase.getCacheKey('access_token');
        Form.beginGroup("proxy_url", "Proxy URL");
        Form.addField(JSON.stringify({
            type: "text",
            id: "proxy_url",
            label: "Proxy Url",
            placeholder: "Enter Url",
            value: proxyUrl
        }));
        Form.setSubmitHandler("saveProxyUrl");
        Form.endGroup();

        Form.beginGroup("tmdb_api_group", "TMDB Api");
        Form.addField(JSON.stringify({
            type: "text",
            id: "tmdb_api_key",
            label: "Api Key",
            placeholder: "Enter Api Key",
            value: tmdb_api_key
        }));
        Form.addField(JSON.stringify({
            type: "text",
            id: "access_token",
            label: "Api Access Token",
            placeholder: "Enter Access Token",
            value: access_token
        }));

        Form.setSubmitHandler("saveTmdb");
        Form.endGroup();

        Form.beginGroup("m34u_group", "M3U4U.com IPTV");
        Form.addField(JSON.stringify({
            type: "text",
            id: "m3u_url",
            label: "M3U Url",
            placeholder: "Enter Api Key",
            value: "M3U Url"
        }));
        Form.addField(JSON.stringify({
            type: "text",
            id: "epg_url",
            label: "EPG URL",
            placeholder: "EPG URL",
            value: "Epg URL"
        }));
        Form.setSubmitHandler("saveProfile");
        Form.endGroup();
        console.log("Database keys loaded successfully");

    } catch (e) {
        console.error("Failed to load keys: " + e);
    }
})();

async function saveTmdb(jsObject) {
    var data = JSON.parse(jsObject);
    await PluginDatabase.setCacheKey('tmdb_api_key', data.tmdb_api_key, 'core')
    await PluginDatabase.setCacheKey('access_token', data.access_token, 'core')
}

async function saveProxyUrl(jsObject) {
    var data = JSON.parse(jsObject);
    console.log(`Saving data ${data.proxy_url}`)
    await PluginDatabase.setCacheKey('proxy_url', data.proxy_url, 'core')
}